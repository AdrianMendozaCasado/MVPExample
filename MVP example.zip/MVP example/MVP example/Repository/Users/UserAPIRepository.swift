//
//  UserAPIRepository.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation
import Alamofire

class UserAPIRepository: UserRepository {
    
    func fetchUsers(OnSuccess: @escaping ([User]) -> Void,
                    OnError: @escaping (Error) -> Void) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else {
            return
        }
        
        Alamofire.request(url).validate().responseJSON() { response in
            guard let data = response.data else {
                return
            }
            do {
                let userDecoded = try JSONDecoder().decode([User].self, from: data)
                OnSuccess(userDecoded)
            } catch {
                OnError(NSError(domain: response.description, code: 403, userInfo: nil))
            }
        }
    }
}

