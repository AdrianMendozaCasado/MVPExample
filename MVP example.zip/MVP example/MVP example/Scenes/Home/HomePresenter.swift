//
//  HomePresenter.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

class HomePresenter: HomePresenterInterface {
    
    weak var view: HomeViewInterface!
    var wireframe: HomeWireframe!
    var text = ""
    
    func didLoad() {
        view.labelSayHello()
    }
    
    func changeLabelState() {
        view.labelSayBye()
    }
    
    func navigateToSecondView() {
        wireframe.navigateToSecondView(from: view, text: text)
    }
}
