//
//  HomeViewController.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    var presenter: HomePresenterInterface?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.didLoad()
    }

    @IBAction func buttonPressed(_ sender: Any) {
        presenter?.changeLabelState()
    }
    
    @IBAction func navigateButton(_ sender: Any) {
        presenter?.navigateToSecondView()
    }
    
}

extension HomeViewController: HomeViewInterface {
   
    func labelSayHello() {
        label.text = "Hello"
        presenter?.text = label.text ?? ""
    }
    
    func labelSayBye() {
        label.text = "Bye"
        presenter?.text = label.text ?? ""
    }
    
    
    
}
