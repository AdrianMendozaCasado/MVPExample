//
//  HomeConfigurator.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

class HomeConfigurator {
    
    class func prepareScene(forViewController viewController: HomeViewController) {
        let presenter = HomePresenter()
        let wireframe = HomeWireframe()
        presenter.view = viewController
        presenter.wireframe = wireframe
        viewController.presenter = presenter
    }
}
