//
//  HomeWireframe.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation
import UIKit

protocol HomeWireframeInterface: class {
    static func prepareHomeScene(window: UIWindow) -> UIViewController
}

class HomeWireframe: HomeWireframeInterface {
    
    static func prepareHomeScene(window: UIWindow) -> UIViewController {
        let homeSB = UIStoryboard(name: "Home", bundle: nil)
        let homeVC = homeSB.instantiateViewController(withIdentifier: "Home") as! HomeViewController
        let navigationCointroller = UINavigationController(rootViewController: homeVC)
        HomeConfigurator.prepareScene(forViewController: homeVC)
        window.rootViewController = navigationCointroller
        return navigationCointroller
    }
    
    func navigateToSecondView(from view: HomeViewInterface, text: String) {
        let secondVC = SecondViewWireframe.prepareSecondView(text: text)

        if let sourceView = view as? UIViewController {
            sourceView.navigationController?.pushViewController(secondVC, animated: true)
        }
    }
}

