//
//  SecondViewInteractor.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

class SecondViewInteractor {
    var presenter: SecondViewPresenterInterface!
    var userRepository: UserRepository!
    
    func passUserName(OnComplete: @escaping (String) -> Void) {
        userRepository.fetchUsers(OnSuccess: { (userData) in
                OnComplete(userData[0].name ?? "Unknown Name")
            }, OnError: { (Error) in
                print(Error)
        })
        
    }
}

