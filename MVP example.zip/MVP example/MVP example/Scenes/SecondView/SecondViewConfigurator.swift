//
//  SecondViewConfigurator.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

class SecondViewConfigurator {

    class func prepareScene(forViewController viewController: SecondViewController, text: String) {
        
        let presenter = SecondViewPresenter()
        let wireframe = SecondViewWireframe()
        let interactor = SecondViewInteractor()
        presenter.view = viewController
        presenter.wireframe = wireframe
        presenter.interactor = interactor
        presenter.text = text
        interactor.presenter = presenter
        interactor.userRepository = UserAPIRepository()
        viewController.presenter = presenter
    }
}

