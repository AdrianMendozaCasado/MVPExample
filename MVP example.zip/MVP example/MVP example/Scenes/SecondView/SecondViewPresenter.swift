//
//  SecondViewPresenter.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

class SecondViewPresenter: SecondViewPresenterInterface {
    weak var view: SecondViewInterface!
    var wireframe: SecondViewWireframe!
    var interactor: SecondViewInteractor!    
    var text = ""

    func didLoad() {
        view.showLabelText(text: text)
        interactor.passUserName(OnComplete: { [weak self] (name) in
            guard let strongSelf = self else {
                return
            }
            strongSelf.view.setUserName(name: name)
        })
    }
}
