//
//  SecondViewWireframe.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation
import UIKit

class SecondViewWireframe {
    
    class func prepareSecondView(text: String) -> UIViewController {
        let secondSB = UIStoryboard(name: "SecondView", bundle: nil)
        let secondVC = secondSB.instantiateViewController(withIdentifier: "SecondView") as! SecondViewController
        SecondViewConfigurator.prepareScene(forViewController: secondVC, text: text)
        return secondVC
    }
}
