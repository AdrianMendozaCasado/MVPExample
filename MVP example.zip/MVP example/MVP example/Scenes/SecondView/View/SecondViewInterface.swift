//
//  SecondViewInterface.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import Foundation

protocol SecondViewInterface: class {
    
    func showLabelText(text: String)
    func setUserName(name: String)
}
