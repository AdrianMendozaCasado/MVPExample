//
//  SecondViewController.swift
//  MVP example
//
//  Created by a.mendoza.casado on 16/02/2019.
//  Copyright © 2019 a.mendoza.casado. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var nameOne: UILabel!
  
    
    
    var presenter: SecondViewPresenterInterface?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.didLoad()
    }
}

extension SecondViewController: SecondViewInterface {
    func showLabelText(text: String) {
        label.text = text
    }
    
    func setUserName(name: String) {
        nameOne.text = name
    }
    
    
}
